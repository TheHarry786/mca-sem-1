<?php
session_start();
include 'conn.php';
if($_SESSION['username']==''){
    header("location: login.php");
}
	
	echo "<h2 align='center'>welcome ".$_SESSION['username']."</h2>";
	echo "<h2 align='center'><a href='logout.php'>Logout</a></h2>";

	
	$sql1 = "select * from customer";

	$res1 = mysqli_query($mysqli, $sql1);

	if($res1->num_rows>0)
	{
		echo "<h1 align='center'>Customer Trascation Details</h1>";
		echo "<table border='1' cellpadding='5px' align='center' bgcolor='sky blue'>";
		echo "<tr><th>Customer ID</th><th>Customer Name</th><th>Trascation</th></tr>";
		while($row = mysqli_fetch_array($res1, MYSQLI_ASSOC))
		{
			$id=$row['cid'];
			$name=$row['cust_name'];
			$cy=$row['transaction'];


			echo "<tr><td>$id</td><td>$name</td>";
			echo "<td>$cy</td>";
			echo "</tr>";	

		}
		echo "</table>";			
	}
	
	else
	{
		//echo "error";
		header("location:index.php");
	}
?>