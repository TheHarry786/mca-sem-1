<form method="post" align="center">
	<h1 style="font-size: 50px; color: blue;">Customer Registraion</h1>
	<h2><b>Customer Name :</b> 
		<input type="text" name="name" required><br/><br/></h2>
	<h2 style="margin-left:70px;"><b>Enter Password :</b> 
		<input type="password" name="ps" required></h2>
	<h2 style="margin-left:70px;"><b>Trasaction :</b> 
		<input type="number" name="ts" required></h2>
	<input type="submit" name="submit" value="Registraion">
	<a href="index.php">login</a>
</form>
<?php

		include("conn.php");
		if(isset($_POST['submit']))
		{
			$nm = $_POST['name'];
			$ps = $_POST['ps'];
			$ts = $_POST['ts'];
		
			$sql="insert into customer VALUES (null,'$nm','$ps','$ts')";
			$res = $mysqli->query($sql);

			if ($res === TRUE) {
				echo "A record has been inserted.";
				header("location:index.php");
			} 
			else {
				echo "not inserted..";
			}
			mysqli_close($mysqli);
			
		}
	
?>