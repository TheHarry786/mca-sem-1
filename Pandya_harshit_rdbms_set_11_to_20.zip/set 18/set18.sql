create table BRANCH(
branch_no number(10) primary key,
area varchar2(20),
city varchar2(20)
);

insert into branch values(2102,'local','jamnagar');
insert into branch values(22193,'city','jamnagar');
insert into branch values(2393,'city','rajkot');
insert into branch values(2533,'city','ahemdabad');
insert into branch values(2232,'city','ahemdabad');

create table MEMBERS 
(mno number(20) primary key,
name varchar2(20),
branch_no number(10) REFERENCES BRANCH(branch_no),
salary number(20),
manager_no number(20)
);

insert into members values(323,'raj',2102,51000,85);
insert into members values(23,'mahesh',22193,10000,515);
insert into members values(413,'kitten',2393,5000,850);
insert into members values(873,'mishra',2393,1000,857);
insert into members values(814,'mira',2533,51000,87);
insert into members values(84,'riya',2533,10000,814);


/*
BRANCH (branch_no, area, city)
MEMBERS (mno, name branch_no, salary, manager_no)
Note: Manager can be from one of the members.
*/
--1. Write a procedure which list the name of members who earns more than that of his managers.


create or replace procedure members_erans_higher
is
	cursor c1 is 
	select a.mno,a.name,a.salary as mem_salary,b.manager_no,b.salary as mgr_salary 
	from members a,members b 
	where a.mno=b.manager_no and a.salary > b.salary;
begin	
	dbms_output.put_line(rpad('-',65,'-'));
	  dbms_output.put_line(upper(
				 
				rpad('mname',10) ||
				rpad('salary',10)
				  
			));
	dbms_output.put_line(rpad('-',65,'-'));
	for r in c1 loop
		
			dbms_output.put_line(upper(
				 
				rpad(r.name,10) ||
				rpad(r.mem_salary,10) 
			)); 
		
	end loop;
	dbms_output.put_line(rpad('-',65,'-'));
end;
/
exec members_erans_higher


--2. Write a procedure which gives details of employee having maximum salary branch wise.
-----------------------------------------------------------------------------------------

create or replace procedure emp_grp_max_sal
is
	cursor c1 is 
	select branch_no,max(salary) as mx_salary from members group by branch_no;
begin	
	dbms_output.put_line(rpad('-',65,'-'));
	  dbms_output.put_line(upper(
				 
				rpad('branch_no',10) ||
				rpad('mx_salary',10)
				  
			));
	dbms_output.put_line(rpad('-',65,'-'));
	for r in c1 loop
		
			dbms_output.put_line(upper(
				 
				rpad(r.branch_no,10) ||
				rpad(r.mx_salary,10) 
			)); 
		
	end loop;
	dbms_output.put_line(rpad('-',65,'-'));
end;
/
exec emp_grp_max_sal