create table EMPP
(
empno number(10) primary key,
empnm varchar2(20),
empadd varchar2(20),
salary number(20),
date_birth date,
joindt date,
deptno number(10)
);

insert into empp values(101,'harshit','amreli',45000,'2-Feb-2001','21-Jan-2020',1);
insert into empp values(201,'rajesh','rajkot',15000,'2-Feb-2001','21-Jan-2020',2);
insert into empp values(301,'yash','ahemdabad',25000,'2-Feb-2001','21-Jan-2020',3);
insert into empp values(401,'jayesh','nagpur',50000,'2-Feb-2001','21-Jan-2020',4);
insert into empp values(501,'mahesh','baroda',40000,'2-Feb-2001','21-Jan-2020',5);

--1. Write a PLSQL block which will print Employee list (Empno and Name)
--EMP (empno, empnm, empadd, salary, date_birth, joindt, deptno)
Declare
	cursor c1 is select empno,empnm from empp;
begin	
	dbms_output.put_line(rpad('-',50,'-'));
	dbms_output.put_line(upper(rpad('emp no',20)|| rpad('emp name',20)));	
	dbms_output.put_line(rpad('-',50,'-'));
	for r in c1 loop
		dbms_output.put_line(upper(rpad(r.empno,20)|| rpad(r.empnm,20)));
	end loop;
	dbms_output.put_line(rpad('-',50,'-'));
end;
/

--------------------------
create table JOB
(
jobid number(10) primary key,
type_of_job varchar2(20),
status varchar2(20)
);

insert into job values(120,'hod','comlete');
insert into job values(123,'sr','incomplete');
insert into job values(103,'hr','complete');
insert into job values(154,'peon','incomplete');
insert into job values(170,'CA','complete');

--2. Write a function that returns total number of incomplete jobs, using table JOB (jobid, type_of_job, status)
create or replace function incomplete_job_count
return number
is
	ic_job number(4);	 
begin	
	select count(*) into ic_job from job where status='incomplete';
	return(ic_job);
	
end;
/

-------------------
create table ITEMI
(
itemno number(10) primary key,
name varchar2(20),
color varchar2(20),
weight number(20)
);

insert into ITEMI values(1202,'cookie','green',20);
insert into ITEMI values(1262,'cake','red',50);
insert into ITEMI values(1242,'colgate','white',10);
insert into ITEMI values(1232,'egg','red',5);

-- 3. Write a function which displays the number of items whose weight fall between a
-- given ranges for a particular color using table ITEM (itemno, name, color, weight)

 

create or replace function display_item_count(c varchar2,l number,h number)
return number
is
	icount number(4);	 
begin	
	select count(*) into icount from itemi where color=c and weight between l and h;
	return(icount);
	
end;
/

declare
	ans number(4);
begin
	ans:=display_item_count('green',10 ,600);
	dbms_output.put_line('number of items : '||ans );
end;
/

---------------

create table WORKER(
workerid number(10) primary key,
name varchar2(10), 
wage_per_hour number(10),
specialized_in varchar2(20),
manager_id number(10)
);

insert into worker values(102,'raju',10,'php',102);
insert into worker values(122,'minakshi',14,'android',126);
insert into worker values(1503,'minal',8,'asp.net',152);
insert into worker values(1223,'kinal',12,'java',187);
insert into worker values(1652,'mahesh',7,'python',196);

-- 4. Write a procedure to display top five highest paid workers who are specialized in ‘PAINTING" using table 
-- WORKER (workerid, name, wage_per_hour, specialized_in,manager_id)
Declare
	cursor c1 is 
	select WORKERID, NAME, WAGE_PER_HOUR, SPECIALIZED_IN,MANAGER_ID 
	from worker  where SPECIALIZED_IN='php' order by wage_per_hour desc;
	n number;
begin		
	n:=1;
	dbms_output.put_line(rpad('-',50,'-'));
	dbms_output.put_line(upper(
			rpad('ID',10)|| rpad('NAME',10)||
			rpad('WPH',10)|| rpad('SP_IN',10)|| rpad('MGR_ID',10)
		));
	dbms_output.put_line(rpad('-',50,'-'));
	for r in c1 loop
		if n>5 then
			EXIT ;
		end if;	
		dbms_output.put_line(upper(
			rpad(r.WORKERID,10)|| rpad(r.NAME,10)||
			rpad(r.WAGE_PER_HOUR,10)|| rpad(r.SPECIALIZED_IN,10)|| rpad(r.MANAGER_ID,10)
		));
		n:=n+1;
	end loop;
	dbms_output.put_line(rpad('-',50,'-'));
end;
/