create table EMPMAST 
(
empno number(20) primary key,
name varchar2(20),
pfno number(20),
empbasic varchar2(20),
deptno number(10) REFERENCES DEPTu(DNO),
designation varchar2(20)
);

insert into empmast values(1012,'raj',1000,50000,1032,'manager');
insert into empmast values(112,'mahesh',1500,30000,102,'peon');
insert into empmast values(1015,'mukesh',850,25000,152,'worker');
insert into empmast values(162,'mishra',700,65000,1322,'clerk');
insert into empmast values(128,'mira',300,15000,1072,'operator');

create table DEPTu
(
DNO number(10) primary key, 
DNAME varchar2(20)
);

insert into DEPTu values(1072,'hr');
insert into DEPTu values(102,'hr');
insert into DEPTu values(152,'ca');
insert into DEPTu values(1322,'sr');
insert into DEPTu values(1032,'peon');

/*
EMPMAST (empno, name, pfno, empbasic, deptno, designation)
DEPT (DNO, DNAME)
Rules: 
HRA = 15% of basic
DA = 50% of basic
Medical = 100
PF = 8.33%of basic
Print Salary slip. Design your own format
*/

declare
	cursor c1 is 
	select e.empno,e.name,e.empbasic,e.designation,d.dname
	from empmast e,DEPTu d where e.deptno=d.dno;
	HRA number(8,2);
	DA number(8,2);
	Medical number(8,2);
	PF number(8,2);
	amt number(8,2);
begin	
	dbms_output.put_line(rpad('-',100,'-'));
	dbms_output.put_line(upper(
			rpad('empno',10)|| rpad('ename',10)||
			rpad('job',10)|| rpad('sal',10)|| 
			rpad('HRA',10)||rpad('DA',10)||rpad('Medical',10)||rpad('PF',10)||rpad('amt',10)
		));
	dbms_output.put_line(rpad('-',100,'-'));
	for r in c1 loop
		HRA:= (r.empbasic*15)/100;
		DA:= (r.empbasic*50)/100;
		Medical:= 100;
		PF:= (r.empbasic*8.33)/100;
		amt:= (r.empbasic+HRA+DA+Medical)-PF;
		
		dbms_output.put_line(upper(
			rpad(r.empno,10)|| rpad(r.name,10)||
			rpad(r.designation,10)|| rpad(r.empbasic,10)|| 
			rpad(HRA,10)||rpad(DA,10)||rpad(Medical,10)||rpad(PF,10)||rpad(amt,10)
		)); 
		
	end loop;
	dbms_output.put_line(rpad('-',100,'-'));
end;
/