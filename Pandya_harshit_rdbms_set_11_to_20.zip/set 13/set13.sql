create table DISTRIBUTOR
(
dno number(10) primary key,
dname varchar2(20),
daddress varchar2(20),
dphone number(10)
);

insert into distributor values(101,'harry','Jamnagar',8464858645,'145-222');
insert into distributor values(102,'Abhay','rajpur',7858545482,'897-221');
insert into distributor values(103,'Yash','Jamnagar',9847782784,'7820-22');
insert into distributor values(104,'Priyank','junagadh',7942878285,'856-232');
insert into distributor values(105,'hardik','Jamnagar',8452786874,'457-789');
insert into distributor values(106,'metaohbhi','mispur',7475828577,'452-421');
insert into distributor values(107,'misri','bhavnagar',7475682555,'452-124');

create table ITEMM
(
itemno number(10) primary key,
itemname varchar2(20),
colour varchar2(20),
weight number(10)
);

insert into itemm values(432,'fruite-cake','green',20);
insert into itemm values(784,'eggs','red',7);
insert into itemm values(421,'pens','white',3);
insert into itemm values(741,'board','black',10);
insert into itemm values(852,'biscuite','green',10);
insert into itemm values(963,'teddy_bear','white',10);
insert into itemm values(369,'vefers','green',15);
insert into itemm values(258,'chocho','red',7);

create table DIST_ITEM 
(
dno number(10) REFERENCES DISTRIBUTOR(dno),
itemno number(10) REFERENCES ITEMM(itemno),
qty number(10)
);

insert into dist_item values(105,369,5);
insert into dist_item values(103,852,4);
insert into dist_item values(101,421,10);
insert into dist_item values(104,258,8);
insert into dist_item values(106,784,10);
insert into dist_item values(106,784,10);
insert into dist_item values(105,784,5);
insert into dist_item values(102,963,3);
insert into dist_item values(103,963,5);
insert into dist_item values(101,784,4);

--1. Add a column CONTACT_PERSON to the DISTRIBUTOR table with the not null 
--constraint.
 
 alter table distributor add contact_person varchar(20) not null;
 
 
--2. Create a view LONDON_DIST on DIST_ITEM which contains only those records 
--where distributors are from London. Make sure that this condition is checked for every 
--DML against this view.


--3. Display the details of all those items that have never been supplied.

select * from itemm where itemno not in (select itemno from dist_item);


--4. Delete all those items that have been supplied only once. -d
DELETE FROM DIST_ITEM 
WHERE dno IN(SELECT dno FROM DIST_ITEM GROUP BY dno HAVING COUNT(*)=1);
---krrrr fireeeeeee rdy hale che biji joto rdy che

--5. List the names of distributors who have an ‘A’ and also a ‘B’ somewhere in their names.
select dname from distributor where dname like '%a%' and dname LIKE '%b%';

--6. Count the number of items having the same colour but not having weight between 20 and 100.
select count(itemno),colour,weight from itemm 
where weight not BETWEEN 10 and 20
 group by colour,weight having count(colour)>1;

--7. Display all those distributors who have supplied more than 1000 parts of the same type. -d
select d.* from distributor d,itemm i,dist_item di 
where d.dno=di.dno and i.itemno = di.itemno and di.qty>=7;

--8. Display the average weight of items of the same colour provided at least three items have That colour.
select avg(weight),colour from itemm group by colour having count(colour)>2;

--9. Display the position where a distributor name has an ‘OH’ in its spelling somewhere after the fourth character.
select dname from distributor where dname like '____oh%'; joyu hali gy saras. hheeh tare hale che ha ____ varu


--10. Count the number of distributors who have a phone connection and are supplying item number ‘I100’. -d
select count(d.dno) from distributor d,dist_item di where d.dno=di.dno and di.itemno=784; 

--or--
select count(d.dno),d.dphone from distributor d,dist_item di 
where d.dno=di.dno and di.itemno=784 group by d.dphone;
 
---11. Create a view on the tables in such a way that the view contains the distributor name, item name and the quantity supplied.

create or REPLACE view v23 as 
select distinct d.dname,i.itemname,di.qty
from distributor d,itemm i,dist_item di 
where d.dno=di.dno and i.itemno=di.itemno; 

--12. List the name, address and phone number of distributors who have the same three digits in their number as ‘Mr. Talkative’.
select dname,dphone,daddress from distributor where SUBSTR(dphone,1,3) in 
(select SUBSTR(dphone,1,3) from distributor where dname='metaohbhi') and dname != 'metaohbhi';

--13. List all distributor names who supply either item I1 or I7 or the quantity supplied is more than 100.
select d.dno,d.dname from distributor d where dno in(select dno from dist_item where (itemno=258 or itemno=784) and qty>5);

-- 14. Display the data of the top three heaviest ITEMS.
SELECT weight
FROM (SELECT weight FROM ITEMM order by weight DESC)
WHERE ROWNUM <= 3;