create table ACCOUNT
(
AC_NO number(10) primary key,
NAME varchar2(20),
AC_TYPE varchar2(20),
BALANCE_AMT number(20),
BALANCE_DATE date
);

insert into ACCOUNT values(125315,'rajesh','saving',40000,'21-Dec-2021');
insert into ACCOUNT values(127715,'mahesh','fix-depo',60000,'2-Feb-2021');
insert into ACCOUNT values(129315,'kanti','recuring depo',30000,'10-Jan-2021');
insert into ACCOUNT values(425441,'rajesh','salary-ac',80000,'1-Dec-2021');

----------------
create table TRANSACTIONN 
(AC_NO number(10) REFERENCES ACCOUNT(AC_NO),
DATEe date,
TR_TYPE varchar2(20), 
AMOUNT number(10),
PREV_BALANCE number(10),
REMARK varchar2(20)
);

insert into TRANSACTIONN values(125315,'22-Jan-2022','credit',4000,40000,'glosary'); 
insert into TRANSACTIONN values(125315,'25-Jan-2022','credit',10000,36000,'fees'); 
insert into TRANSACTIONN values(127715,'2-Jan-2022','deposit',14000,60000,'Add'); 
insert into TRANSACTIONN values(129315,'25-Jan-2022','credit',20000,30000,'phone');
insert into TRANSACTIONN values(425441,'20-Jan-2022','credit',1000,80000,'phone-balance'); 



/*
Consider the Bank schema as
ACCOUNT (AC_NO, NAME, AC_TYPE, BALANCE_AMT, BALANCE_DATE)
TRANSACTION (AC_NO, DATE, TR_TYPE, AMOUNT, PREV_BALANCE,REMARK)
Note: 1. AC_type may be S for saving or C for current, 2. TR_type may be D for deposit or W
for withdrawal.
a. Write a procedure to print the Bank Transaction details by passing from and to dates.
*/
--------------------------------------------------------------------------------------------------------------
create or replace procedure Bank_Transaction(sd date,ed date)
is
	cursor c1 is 
	select ac_no,datee,tr_type,amount,prev_balance 
	from TRANSACTIONN where datee between sd and ed;
begin	
	dbms_output.put_line(rpad('-',65,'-'));
	  dbms_output.put_line(upper(
				rpad('ac_no',10) ||
				rpad('tr_date',10) ||
				rpad('tr_type',10) ||
				rpad('amount',10) ||
				rpad('prev_balance',10) 
			));
	dbms_output.put_line(rpad('-',65,'-'));
	for r in c1 loop
		
			dbms_output.put_line(upper(
				rpad(r.ac_no,10) ||
				rpad(r.datee,10) ||
				rpad(r.tr_type,10) ||
				rpad(r.amount,10) ||
				rpad(r.prev_balance,10) 
			)); 
		
	end loop;
	dbms_output.put_line(rpad('-',65,'-'));
end;
/

exec Bank_Transaction('1-jan-2022', '20-jan-2022');