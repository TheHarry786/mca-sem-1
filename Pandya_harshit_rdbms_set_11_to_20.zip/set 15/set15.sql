create table EMPps 
(
empno number(10) primary key,
empnm varchar2(20),
empadd varchar2(20),
salary number(20),
date_birth date,
joindt date,
deptno number(10) REFERENCES Deptt);

insert into empps values(319,'raj','rajkot',40000,'21-Dec-2002','21-Dec-2020',1212);
insert into empps values(410,'jayesh','rajpur',52000,'21-Jan-2001','1-Jan-2020',1212);
insert into empps values(741,'konish','bhavnagar',34000,'1-Feb-2004','21-Feb-2020',12322);
insert into empps values(385,'mahesh','jamangar',45000,'12-Mar-2001','1-Mar-2020',1652);
insert into empps values(941,'mukesh','ahemdabad',50000,'3-Jan-2000','21-Jan-2020',13212);

-----------------------
create table Deptt(
deptno number(10) primary key,
deptnm varchar2(20)
);
insert into deptt values(1212,'ca');
insert into deptt values(12322,'peon');
insert into deptt values(1652,'sr');
insert into deptt values(12632,'hr');
insert into deptt values(13212,'hra');
/*
EMP (empno, empnm, empadd, salary, date_birth, joindt, deptno)
DEPT (deptno, deptnm)
Write a PL/SQL block (table above EMP-DEPT table) which takes as input Department name and displays all the employees of this department who has been working since last five years
*/
Declare
	cursor c1 is 
	select empno,empnm,salary,joindt,(sysdate-joindt)/365 as nYears 
	from empps,deptt where empps.deptno=deptt.deptno and deptt.deptnm='&dept_name';
begin		
	 
	dbms_output.put_line(rpad('-',50,'-'));
	dbms_output.put_line(upper(
			rpad('empno',10)|| rpad('ename',10)||
			rpad('job',10)|| rpad('sal',10)|| rpad('nYears',10)
		));
	dbms_output.put_line(rpad('-',50,'-'));
	for r in c1 loop
		if r.nYears>1 then
			dbms_output.put_line(upper(
				rpad(r.empno,10)|| rpad(r.empnm,10)||
				rpad(r.joindt,10)|| rpad(r.salary,10)|| rpad(r.nYears,10)
			)); 
		end if;			 
	end loop;
	dbms_output.put_line(rpad('-',50,'-'));
end;
/