create table Employess
(
eid number(20) primary key,
fname varchar2(20),
lname varchar2(20),
salary number(20)
);

insert into employess values(522,'raj','mishra',42200);
insert into employess values(42,'mahesh','gor',42200);
insert into employess values(52,'mira','patel',42200);
insert into employess values(527,'rina','rajshri',42200);

--Employee (eid, fname, lname, salary)
/* 1. Use a Cursor for Loop inside a function to calculate and return total paid salary to all employees by the company. */

create or replace function total_paid_salary
return number
is
	tot_sal number(8);	
	cursor c1 is 
	select eid,fname,lname,salary from Employess;	
begin	
	tot_sal:=0;
	 for r in c1 loop
			tot_sal:=tot_sal+r.salary;			 
	end loop;
	return(tot_sal);
	
end;
/

declare
	ans number(8);
begin
	ans:=total_paid_salary;
	dbms_output.put_line('number of items : '||ans );
end;
/

-----------------------------------------------------------------------------------------------------------
/*
2. Modify the function created above to become a procedure and display the total paid salary
from the procedure itself. Instead of calculating for all employees, calculate only for those
employees whose name starts from a character passed as parameter to the procedure and
hence to the cursor.
*/

create or replace procedure total_paid_salary_of_emp(ch varchar2)
is
	tot_sal number(8);	
	cursor c1 is 
	select eid,fname,lname,salary from Employess where fname like ch||'%';	
begin	
	tot_sal:=0;
	 for r in c1 loop
			tot_sal:=tot_sal+r.salary;			 
	end loop;
	dbms_output.put_line('Total Salary : '||tot_sal );
	
end;
/

exec total_paid_salary_of_emp('m');