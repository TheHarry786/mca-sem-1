<html>
    <head>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    </head>
    <body>
        <h1 align="center">Form insert</h1>
    <form >
        First Name:<br>
        <input type="text" id="fname" name="fname"><br>
        Last Name:<br>
        <input type="text" id="lname" name="lname"><br>
        Email:<br>
        <input type="text" id="email" name="email"><br>
        Message:<br>
        <textarea type="text" name="message" id="message"></textarea><br><br>
        <input id="submit" name="submit" type="button" class="btn-submit" value="submit"/>
    </form>
    <script>
        $(document).ready(function(){
            $("#submit").click(function(){
                var fname = $("#fname").val();
                var lname = $("#lname").val();
                var email = $("#email").val();
                var message = $("#message").val();

                $("#fname").css("background-color","#fff");
                $("#lname").css("background-color","#fff");
                $("#email").css("background-color","#fff");
                $("#message").css("background-color","#fff");

                if(fname==''){
                    alert("please fill first name");
                    $("#fname").focus();
                    $("#fname").css("background-color","ff0000");
                    return false;
                }
                else if(lname==''){
                    alert("please fill last name");
                    $("#lname").focus();
                    $("#lname").css("background-color","ff0000");
                    return false;
                }  
                else if(email==''){
                    alert("please fill email");
                    $("#email").focus();
                    $("#email").css("background-color","ff0000");
                    return false;
                }
                else if(message==''){
                    alert("please fill message");
                    $("#message").focus();
                    $("#message").css("background-color","ff0000");
                    return false;
                }   
                $.ajax({
                    type:"POST",
                    url: "e30.php",
                    data:{
                        fname:fname,
                        lname:lname,
                        email:email,
                        message:message
                    },
                    cache: false,
                    success:function(data){
                            alert(data);
                    },
                    error:function(xhr,status,error){
                        console.error(xhr);
                    }
                });
            });
        });
    </script>
    </body>
</html>