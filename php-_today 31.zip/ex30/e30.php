<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";


    $fm= $_POST['fname'];
    $lm =$_POST['lname'];
    $em =$_POST['email'];
    $ms =$_POST['message'];

    $sql = "insert into demo values('','$fm','$lm','$em','$ms')";
    echo "registration successfully";
   
?>