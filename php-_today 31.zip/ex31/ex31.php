<?php
$xml=simplexml_load_file("sample.xml")
or die("Error : Cannot Create object");
echo "<table border='1'>";
echo "<tr><th>id</th>";
echo "<th>Title</th>";
echo "<th>Price</th>";
foreach($xml->children() as $r)
{
    echo "<tr><td>".$r->id . "</td>";
    echo "<td>".$r->title . "</td>";
    echo "<td>".$r->price . "</td></tr>"; 
}
echo "</table>";
?>
