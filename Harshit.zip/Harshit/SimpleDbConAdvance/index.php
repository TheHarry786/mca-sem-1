<form align="center" method="post" action="insert.php">

	<br/>
	First name :<input type = "text" name="fname" required>
	
	<br/>
	Middle name :<input type = "text" name="mname" required>
	
	<br/>
	Last name :
	<input type = "text" name="lname" required>
	
	<br/>
	<input type="submit" name= "submit" value="Insert">
	<a href="display.php">Display</a>
</form>
<?php
include("display.php");
?>