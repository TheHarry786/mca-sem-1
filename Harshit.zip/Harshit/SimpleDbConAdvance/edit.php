<?php
include("conn.php");

$id = $_GET['id'];
$sql ="select id,fname,mname,lname from testtable where id=$id";
$res = mysqli_query($mysqli,$sql);

if($res->num_rows)
{
	$row = mysqli_fetch_array($res, MYSQLI_ASSOC);
	
	$id = $row['id'];
	$fm = $row['fname'];
	$mn = $row['mname'];	
	$ln = $row['lname'];
	
	?>
	<form method="post" action="update.php" align="center">
		<br/>
		<input type = "hidden" name="id" value="<?=$id?>">
		First name :<input type = "text" name="fname"  value="<?=$fm?>">
		
		<br/>
		Middle name :<input type = "text" name="mname" id="fname" value="<?=$mn?>">
		
		<br/>
		Last name :
		<input type = "text" name="lname" id="mname" value="<?=$ln?>">
		
		<br/>
		<input type="submit" name= "submit" value="Update">	
			<a href="display.php">cancel</a>
	</form>
	<?php
}
else
{
	printf("could not insert into: %s\n",mysqli_error($mysqli));
}
mysqli_close($mysqli);
include("display.php");
?>	