<?php
include("conn.php");

$id = $_POST['id'];
$fm = $_POST['fname'];
$mn = $_POST['mname'];	
$ln = $_POST['lname'];

$sql = "update testtable set fname='$fm',mname='$mn',lname='$ln' where id = $id";

//echo $sql;
$res=mysqli_query($mysqli, $sql);
if($res === TRUE)
{
	echo "record is update";
}
else
{
	printf("could not Update into: %s\n",mysqli_error($mysqli));
}
mysqli_close($mysqli);
include("display.php");
?>