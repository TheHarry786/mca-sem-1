<?php
include("conn.php");
$fm = $_POST["fname"];
$mn = $_POST["mname"];	
$ln = $_POST["lname"];

$sql = "insert into testtable (fname,mname,lname) values ('$fm','$mn','$ln')";
//echo  $sql;
$res=mysqli_query($mysqli, $sql);

if($res === TRUE)
{
	echo "record is insert";
}
else
{
	printf("could not insert into: %s\n",mysqli_error($mysqli));
}
mysqli_close($mysqli);
include("display.php");
?>	
	