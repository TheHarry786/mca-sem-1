<?php
include("conn.php");
	
//echo  $sql;

$id = $_GET['id'];

$sql = "delete from testtable where id= $id";
echo $sql;
$res=mysqli_query($mysqli, $sql);
if($res === TRUE)
{
	echo "record is Delete";
}
else
{
	printf("could not insert into: %s\n",mysqli_error($mysqli));
}
mysqli_close($mysqli);

include("display.php");
?>