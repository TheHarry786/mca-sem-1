
<?php
/*Display goodmorning,good afternoon,good evening and good night according to current time*/
	date_default_timezone_set("Asia/Calcutta");
	$Time = date("H");
	//echo $Time;
	
	if($Time < 12 )
	{
		echo "<h3 style='color:Orange'>Good Morning</h3>";
		
	}
	else if($Time >=12 && $Time <17)
	{
		echo "<h3 style='color:Red; Background-color:Black;'>Good Afternoon</h3>";
	}
	else if($Time >=17 && $Time <19)
	{
		echo "<h3 style='color:skyblue'>Good Evening</h3>";
	}
	else
	{
		echo "<h3 style='color:black'>Good Night</h3>";
	}
?>