<form method="post" action="">
	name :<input type="text" name="name"/>
	values : <input type="text" name="value"/>
	Submit <input type="submit" name="submit"/>
</form>

<?php
	if(isset($_POST['submit']))
	{
		$cookie_name=$_POST['name'];
		$cookie_value=$_POST['value'];
	
		setcookie($cookie_name, $cookie_value, time() + (86400)*30,"/"); //86400 = 1 day
		
		if(!isset($_COOKIE[$cookie_name]))
		{
			echo "cookie name '". $cookie_name . "' is not set!";
		}
		else
		{
			echo "cookie :". $cookie_name;
			echo "cookie value is :". $cookie_value;
			
			
	}
		
	}
	else
	{
		var_dump($_COOKIE);
	}
?>