<?php

	$cookie_name="my_name_is";
	$cookie_value="Harry007";
	
	setcookie($cookie_name, $cookie_value, time() + (40),"/"); //86400 = 1 day
	
	if(!isset($_COOKIE[$cookie_name]))
	{
		echo "cookie name '". $cookie_name . "' is not set!";
	}
	else
	{
		echo "cookie :". $cookie_name;
		echo "cookie value is :". $cookie_value;
		
		
	}
?>