<!--21. Develop an application to add the movie name currently running with following
operations:
a. To see all the favorite movie
b. To view top 5 and 10 movies-->

<?php
	function insert()
	{
		?><body bgcolor="ice blue">
			<form align="center" method="POST" action="">
				<h1 style="font-size:70px;color: Red;"><b>Movie Box<b/></h1>
				<br/><br/>
				<h2 style="font-size :30px;"><b>Movie Name :</b> <input type="text" name="mvn" required><br/><br/></h2>

				<h2 style="font-size :30px;"><b>Favorite :</b> <input type="radio" name="m"><br/><br/></h2>

				<h2 style="font-size :30px;"><b>ratting :</b> <input type="number" name="r" required ><br/><br/></h2>
				<input type="submit" name="submit" value="Submit">
				
			</form><br/><br/>
			<form align="center" method="POST">
			<input type="submit" name="fav" value="favourite Movie See">
			<input type="submit" name="tp" value="Top Movie See">
			</form>
		</body>
		<?php

		$conn= new mysqli("localhost", "root", "", "jvims");
		if(isset($_POST['submit']))
		{
			$nm = $_POST['mvn'];	
				
			$ra = $_POST['r'];
		
			if(isset($_POST['m']))
			{
				$m=1;
			}
			else
			{
				$m=0;
			}
			$sql="insert into movie(Movie_nm,fav,rating) VALUES ('$nm','$m','$ra')";
			$res = $conn->query($sql);

			if ($res === TRUE) {
				echo "A record has been inserted.";
			} else {
				echo "not inserted..";
			}
			mysqli_close($conn);
		}
	}
	insert();
	function display()
	{	
		
			if(isset($_POST['fav']))
			{

				$conn= new mysqli("localhost","root","","jvims");
				$sql = "select * from movie where fav=1";

				$res = $conn->query($sql);

				if($res->num_rows>0)
				{
					echo "<h2 style='color: Blue;'>Favorite Movie Names<h2>";
					echo "<table border='1' cellpadding='5px' align='center'>";
					echo "<tr><th>Favouite Movie Name</tr>";
					while($row = mysqli_fetch_array($res, MYSQLI_ASSOC))
					{
						$nm=$row['Movie_nm'];
						echo "<tr><td>$nm</td>";
						echo "</tr>";	
					}
					echo "</table>";
		
				}
			}
			else if(isset($_POST['tp']))
			{

				$conn= new mysqli("localhost","root","","jvims");
				$sql = "select * from movie where rating>3";

				$res = $conn->query($sql);

				if($res->num_rows>0)
				{
					echo "<h2 style='color: Blue;'>Top Movie Names<h2>";
					echo "<table border='1' cellpadding='5px' align='center'>";
					echo "<tr><th>Top Movie Name<th>Rating</th></tr>";
					while($row = mysqli_fetch_array($res, MYSQLI_ASSOC))
					{
						$nm=$row['Movie_nm'];
						$rat=$row['rating'];
						echo "<tr><td>$nm</td><td>$rat</td>";
						echo "</tr>";	
					}
					echo "</table>";
				}
			}
		else
		{
		$conn= new mysqli("localhost","root","","jvims");
		$sql = "select * from movie";

		$res = $conn->query($sql);

			if($res->num_rows>0)
			{
				echo "<h2 style='color: Blue;'>Movie Names<h2>";
				echo "<table border='1' cellpadding='5px' align='center'>";
				echo "<tr><th>Movie_id</th><th>Movie Name</th><th>Favouite movie</th><th>Rating</th></tr>";
				while($row = mysqli_fetch_array($res, MYSQLI_ASSOC))
				{
					$id=$row['movie_id'];
					$nm=$row['Movie_nm'];
					$faa=$row['fav'];
					$rata=$row['rating'];

					echo "<tr><td>$id</td><td>$nm</td><td>$faa</td><td>$rata</td>";
					echo "</tr>";	

				}
				echo "</table>";
		
			}
		}
		
	}

	display(); 	
?>

