<?php
$fullpath = $_GET['fileSRC'];
if($fullpath)
{
	$fsize = filesize($fullpath);
	$path_parts = pathinfo($fullpath);
	
	header("Content-type:application/octet-stream");
	header("Content-Disposition:filename=\"".$path_parts["basename"]."\"");
	if($fsize)
	{
			header("Content-length: $fsize");
	}
	
	readfile($fullpath);
	exit;
}

?>