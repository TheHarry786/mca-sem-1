<html>
    <head>
        <title>Simple Download Database to excel</title>
    </head>
    <body align="center" >
		
		<h1> Clcik To Download</h1>
		<br>
       <a href="ex.php?fileSRC=beluga.jpg" title="Hp">JPEG</a>
    </body>
</html>