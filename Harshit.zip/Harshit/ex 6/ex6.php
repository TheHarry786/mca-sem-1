<?php

	$a=array(45,3,56,99,561,4);
	echo "<br>".min($a);
	echo "<br>".max($a);
?>