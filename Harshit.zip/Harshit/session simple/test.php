<?php

	session_start();
	if(isset($_SESSION['name']))
	{
		echo $_SESSION['name'];
	}
	else
	{
		$_SESSION['name']='harshit';
	}
?>
<a href="page2.php">next</a>