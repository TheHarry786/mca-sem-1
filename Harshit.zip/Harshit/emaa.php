<table border="5px";> 
<tr>
<th>Emp Name</th>
	<td><?php $em ?></td>
<th>Mobile No</th>
	<td><?php $m ?></td>
<th>Email</th>
	<td><?php $wm ?></td>
<th>Basic sally</th>
	<td><?php $ma ?></td>
</tr>
</table>

<?php
	
	$em = $_GET['ename'];
	echo $em. '</br>';

	$m = $_GET['mno'];
	echo $m. '</br>';

	$wm = $_GET['eemail'];
	echo $wm. '</br>';

	$ma = $_GET['bs'];
	echo $ma. '</br>';
	
	
	$data= ($ma*20)/100;
	echo "<br> hra :".$data;

	$data2=($ma*10)/100;
	echo "<br> hra :".$data2;
	
	$data3= ($ma*12)/100;
	echo "<br> pf:".$data3;

	$data4=($ma*2)/100;
	echo "<br> pt:".$data4;

	$t1=$ma+$data+$data2-$data3-$data4;
	echo "<br> total :".$t1;
?>