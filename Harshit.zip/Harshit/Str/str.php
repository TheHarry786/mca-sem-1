
<?php
//exercise 5
	echo "<br/>";
	echo strpos("hellow there i am harshit","harshit");
	
	echo "<br/>";
	echo strpos("hellow there i am harshit"," ");
	
	echo "<br/>";
	echo strrpos("hellow there i am harshit","there");
	
	echo "<br/>";
	echo stripos("hellow there i am harshit","i");
	
	echo "<br/>";
	echo strripos("hellow there i am harshit","e");
	
?>