<?php
function display()
	{	
		$mysqli = mysqli_connect("localhost", "root", "", "jvims");

				if (mysqli_connect_errno()) {
					printf("Connect failed: %s\n", mysqli_connect_error());
					exit();
				}
		$sql1 = "select cust_no, cust_name, item_purchased, mob_no from customer ";
		$sql1 .= " order by cust_no";

		$res1 = mysqli_query($mysqli, $sql1);

		if($res1->num_rows>0)
		{
			//echo "Show records";
			echo "<table border='1' cellpadding='5px' align='center'>";
			while($row = mysqli_fetch_array($res1, MYSQLI_ASSOC))
			{
				$id=$row['cust_no'];
				$name=$row['cust_name'];
				$item=$row['item_purchased'];
				$mno=$row['mob_no'];
				echo "<tr><td>$id</td><td>$name</td>";
				echo "<td>$item</td><td>$mno</td>";
				echo "<td><a href='index.php?id=$id'>Edit</a></td>";
				echo "<td><a href='index.php?did=$id'>delete</a></td>";
				echo "</tr>";	

			}
			echo "</table>";
	
		}
	}
display();
function insert()
	{
		?>
		
		<form align = "center" action="index.php" method="POST">
			
			<br/>Customer Name : <input type="text" name="cust_name" id="cust_name" required="">
			<br/>Item Purchased : <input type="text" name="item_purchased" id="item_purchased" required="">
			<br/>Mobile No: <input type="text" name="mob_no" id="mob_no" required="">		
			<br/><br/><input type="submit" value="Insert" name="submit">
		</form>
		<?php
			$mysqli = mysqli_connect("localhost", "root", "", "jvims");

			if (mysqli_connect_errno()) {
				printf("Connect failed: %s\n", mysqli_connect_error());
				exit();
			} 
			if(isset($_POST['submit']))
			{
				$name=$_POST['cust_name'];
				$item=$_POST['item_purchased'];
				$mno=$_POST['mob_no'];
			$sql = "INSERT INTO customer (cust_name, item_purchased, mob_no) VALUES ('$name','$item','$mno')";
			$res = mysqli_query($mysqli, $sql);
			if ($res === TRUE) {
				echo "A record has been inserted.";
			} else {
				printf("Could not insert record: %s\n", mysqli_error($mysqli));
			}
			mysqli_close($mysqli);
			header("location:index.php");
			}	
	}

	insert();
	function delete()
	{
		$mysqli = mysqli_connect("localhost", "root", "", "jvims");

				if (mysqli_connect_errno()) {
					printf("Connect failed: %s\n", mysqli_connect_error());
					exit();
				}
		if(isset($_GET["did"]))
		{
		$id=$_GET['did'];	
		$sql = "delete from customer where cust_no=$id";

		$res = mysqli_query($mysqli, $sql);	 
		if ($res === TRUE) {
			echo "A record has been deleted.";
		} else {
			printf("Could not delete record: %s\n", mysqli_error($mysqli));
		}
		mysqli_close($mysqli);
		
		header("location:index.php");
		}
	}
	delete();
	function edit()
	{	

		if(isset($_GET["id"]))
		{
			$mysqli = mysqli_connect("localhost", "root", "", "jvims");

				if (mysqli_connect_errno()) {
					printf("Connect failed: %s\n", mysqli_connect_error());
					exit();
				}
				
			$id=$_GET['id'];
			$sql = "select cust_no, cust_name, item_purchased, mob_no from customer ";
			$sql .= " where cust_no=$id";
			$res = mysqli_query($mysqli, $sql);	

			if($res->num_rows)
			{	
				$row = mysqli_fetch_array($res, MYSQLI_ASSOC);
				$id=$row['cust_no'];
				$name=$row['cust_name'];
				$item=$row['item_purchased'];
				$mno=$row['mob_no'];
				?>

				<form action="index.php" method="POST" align="center">
				<input type="hidden" name="cust_no" value="<?=$id?>">
				<br/>Customer Name: <input type="text" name="cust_name" id="cust_name" value="<?=$name?>">
				<br/>Item Purchased : <input type="text" name="item_purchased" id="item_purchased" value="<?=$item?>">
				<br/>Mobile No : <input type="text" name="mob_no" id="mob_no" value="<?=$mno?>">		
				<br/><input type="submit" value="Update" name="update">
				</form>

				<?php
				
				
			}
		}

		if(isset($_POST['update']))
		{
			$mysqli = mysqli_connect("localhost", "root", "", "jvims");

				if (mysqli_connect_errno()) {
					printf("Connect failed: %s\n", mysqli_connect_error());
					exit();
				}
			$id=$_POST['cust_no'];
			$name=$_POST['cust_name'];
			$item=$_POST['item_purchased'];
			$mno=$_POST['mob_no'];
			$sql = "update customer set cust_name='$name', item_purchased='$item' ,  mob_no='$mno'  where cust_no=$id";
			//echo $sql;
			$res = mysqli_query($mysqli, $sql);
			 
			if ($res === TRUE) {
				echo "A record has been updated.";
			} else {
				printf("Could not updated: %s\n", mysqli_error($mysqli));
			}
			mysqli_close($mysqli);
			
		header("location:index.php");
		}

	}
	edit();	
?>