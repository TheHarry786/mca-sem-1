/*22. Create an application which displays the info about a particular institute which enables
the user to see the faculty list according to department.*/

<?php
	function display()
	{	
		include("conn.php");
		$sql1 = "select * from dept";
		
		$res1 = mysqli_query($mysqli, $sql1);

		if($res1->num_rows>0)
		{
			//echo "Show records";
			echo "<select name='a'>";
			echo "<option>------</option>";
			while($row = mysqli_fetch_array($res1, MYSQLI_ASSOC))
			{
				$name=$row['dname'];
				
				echo "<option>$name</option>";
			}
			
			echo "</select>";
			if(isset($_REQUEST['a']))
			{
				include("conn.php");
				$sql = "select f_name from faculty where did in(select did from dept)";
		
				$e = mysqli_query($mysqli, $sql);
				if($e->num_rows>0)
				{	
					echo "<table border='1' cellpadding='5px' align='center'>";
					while($row = mysqli_fetch_array($e, MYSQLI_ASSOC))
					{
						$name=$row['f_name'];
						echo "<tr><td>$name</td></tr>";
					}
					echo "</table>";
				}					
			}
		}
	}
display();
	
?>