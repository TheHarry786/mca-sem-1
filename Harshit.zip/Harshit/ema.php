<form method="GET"action="emaa.php">
	<h1>Employee Detail</h1>
	<lable>Employee Name :</lable>
	<input type="text" name="ename"><br/><br/>
	
	<lable>Mobile no :</lable>
	<input type="number" name="mno"><br/><br/>
	
	<lable>Email :</lable>
	<input type="email" name="eemail"><br/><br/>
	
	<lable>Basic sallary:</lable>
	<input type="number" name="bs"><br/><br/>
	
	<input type="submit" name="Login">
	
	
	
</form>
