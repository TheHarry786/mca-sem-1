
<?php
/*Display goodmorning,good afternoon,good evening and good night according to current time*/
	date_default_timezone_set("Asia/Calcutta");
	$Time = date("H");
	echo $Time;
	
	if($Time < 12 )
	{
		echo "Good Morning";
	}
	elseif($Time >=12 && $Time <17)
	{
		echo "Good Afternoon";
	}
	elseif($Time >=17 && $Time <19)
	{
		echo "Good Evening";
	}
	else
	{
		echo "Good Night";
	}
?>