<?php
session_start();
	if(isset($_SESSION['id'] || $_COOKIE['name']=='ps'))
	{
		echo "welcome".$_SESSION['name'];
		echo "<a href='logout.php'>Logout</a>";
	}
	else
	{
		//echo "error";
		header("location:login.php");
	}
?>