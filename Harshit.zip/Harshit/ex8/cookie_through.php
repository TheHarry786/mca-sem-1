<?php
	$cn="pc1";
	if(isset($_COOKIE[$cn]))
	{
		$a=$_COOKIE[$cn]+=1;
		setcookie($cn, ''.$a, time() + (86400 * 30), "/");
		echo "<br>Welcome back";
		echo "<br>Total page count : ".$_COOKIE[$cn];
	}
	else
	{
		setcookie($cn, '1', time() + (86400 * 30), "/");
		echo "<br>Welcome user, you have visited this first time";
		echo "<br>Total page count : 1";
	}
	
?>