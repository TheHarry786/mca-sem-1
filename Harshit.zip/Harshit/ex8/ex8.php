<?php
	session_start();
	if(isset($_SESSION['page_count']))
	{
		echo "<br> Welcome back";
		$_SESSION['page_count']+=1;
		date_default_timezone_set("Asia/Calcutta");
		$d=date('h-i-s A');
		echo $d;
	}
	else
	{
		echo "<br>Welcome user, you have visited this first time";
		$_SESSION['page_count']=1;
	}
	echo "<br>Total page count :".$_SESSION['page_count'];
	echo "<br>";
	
	
	
?>