<html>
<head>
    <script>
        function f1()
        {
            x=document.getElementById("txt1").value;
            if(x=="")
            {
                alert("plz enter value");
            }
        }
    </script>
</head>
<body>
    <input type="text" name="txt1" onblur="f1()">
    <input type="text" name="txt2" >
    <input type="submit" name="btn" value="button">
</body>
</html>