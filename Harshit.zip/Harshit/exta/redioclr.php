<form>
Red      
<input type="radio" onClick="document.bgColor='red' " name="r">
<br>
Green
<input type="radio" onClick="document.bgColor='green'" name="r">
<br>
Blue
<input type="radio" onClick="document.bgColor='blue'" name="r">
<br>
</form>