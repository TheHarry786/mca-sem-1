
<?php 
	
	function edit()
	{	

		if(isset($_GET["id"]))
		{
			$mysqli = mysqli_connect("localhost", "root", "", "jvims");

				if (mysqli_connect_errno()) {
					printf("Connect failed: %s\n", mysqli_connect_error());
					exit();
				}
				
			$id=$_GET['id'];
			$sql = "select id, fname, mname, lname from testtable ";
			$sql .= " where id=$id";
			$res = mysqli_query($mysqli, $sql);	

			if($res->num_rows)
			{	
				$row = mysqli_fetch_array($res, MYSQLI_ASSOC);
				$id  = $row['id'];
				$fname = $row['fname'];
				$mname = $row['mname'];
				$lname = $row['lname'];
				?>

				<form action="index.php" method="POST">
				<input type="hidden" name="id" value="<?=$id?>">
				<br/>First Name : <input type="text" name="fname" id="fname" value="<?=$fname?>">
				<br/>Middle Name : <input type="text" name="mname" id="mname" value="<?=$mname?>">
				<br/>Last Name : <input type="text" name="lname" id="lname" value="<?=$lname?>">		
				<br/><input type="submit" value="Update" name="update">
				</form>

				<?php
				
				
			}
		}

		if(isset($_POST['update']))
		{
			$mysqli = mysqli_connect("localhost", "root", "", "jvims");

				if (mysqli_connect_errno()) {
					printf("Connect failed: %s\n", mysqli_connect_error());
					exit();
				}
			$id=$_POST['id'];
			$fname=$_POST['fname'];
			$mname=$_POST['mname'];
			$lname=$_POST['lname'];	
			$sql = "update testtable set fname='$fname', mname='$mname' ,  lname='$lname'  where id=$id";
			//echo $sql;
			$res = mysqli_query($mysqli, $sql);
			 
			if ($res === TRUE) {
				echo "A record has been updated.";
			} else {
				printf("Could not updated: %s\n", mysqli_error($mysqli));
			}
			mysqli_close($mysqli);
		}

	}
	edit();	
	function delete()
	{
		$mysqli = mysqli_connect("localhost", "root", "", "jvims");

				if (mysqli_connect_errno()) {
					printf("Connect failed: %s\n", mysqli_connect_error());
					exit();
				}
		if(isset($_GET["did"]))
		{
		$id=$_GET['did'];	
		$sql = "delete from testtable where id=$id";

		$res = mysqli_query($mysqli, $sql);	 
		if ($res === TRUE) {
			echo "A record has been deleted.";
		} else {
			printf("Could not delete record: %s\n", mysqli_error($mysqli));
		}
		mysqli_close($mysqli);
		}
	}
	delete();
	function display()
	{	
		$mysqli = mysqli_connect("localhost", "root", "", "jvims");

				if (mysqli_connect_errno()) {
					printf("Connect failed: %s\n", mysqli_connect_error());
					exit();
				}
		$sql1 = "select id, fname, mname, lname from testTable ";
		$sql1 .= " order by id";

		$res1 = mysqli_query($mysqli, $sql1);

		if($res1->num_rows>0)
		{
			//echo "Show records";
			echo "<table border='1' cellpadding='5px' align='center'>";
			while($row = mysqli_fetch_array($res1, MYSQLI_ASSOC))
			{
				$id=$row['id'];
				$fname=$row['fname'];
				$mname=$row['mname'];
				$lname=$row['lname'];
				echo "<tr><td>$id</td><td>$fname</td>";
				echo "<td>$mname</td><td>$lname</td>";
				//echo "<td><a href='delete.php?id=$id'>delete</a></td>";
				echo "<td><a href='index.php?id=$id'>edit</a></td>";
				echo "<td><a href='index.php?did=$id'>delete</a></td>";
				echo "</tr>";	

			}
			echo "</table>";
	
		}
	}
display();
function insert()
	{
		?>
		
		<form align = "center" action="index.php" method="POST">
			
			<br/>First Name : <input type="text" name="fname" id="fname" required="">
			<br/>Middle Name : <input type="text" name="mname" id="mname" required="">
			<br/>Last Name : <input type="text" name="lname" id="lname" required="">		
			<br/><br/><input type="submit" value="Insert" name="submit">
		</form>
		<?php
			$mysqli = mysqli_connect("localhost", "root", "", "jvims");

			if (mysqli_connect_errno()) {
				printf("Connect failed: %s\n", mysqli_connect_error());
				exit();
			} 
			if(isset($_POST['submit']))
			{
			$fname=$_POST['fname'];
			$mname=$_POST['mname'];
			$lname=$_POST['lname'];
			$sql = "INSERT INTO testtable (fname, mname, lname) VALUES ('$fname','$mname','$lname')";
			$res = mysqli_query($mysqli, $sql);
			if ($res === TRUE) {
				echo "A record has been inserted.";
			} else {
				printf("Could not insert record: %s\n", mysqli_error($mysqli));
			}
			mysqli_close($mysqli);
			header("location:index.php");
			}	
	}

	insert();
?>