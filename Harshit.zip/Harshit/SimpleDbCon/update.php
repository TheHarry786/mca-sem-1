<?php
$mysqli = mysqli_connect("localhost","root","","jvims");

if(mysqli_connect_errno())
{
	printf("connect failed: %s\n",mysqli_connect_error());
	exit();
}
else
{
	
	//echo  $sql;
	
	
	$id = $_POST['id'];
	$fm = $_POST['fname'];
	$mn = $_POST['mname'];	
	$ln = $_POST['lname'];
	
	$sql = "update testtable set fname='$fm',mname='$mn',lname='$ln' where id = $id";
	
	//echo $sql;
	$res=mysqli_query($mysqli, $sql);
	if($res === TRUE)
	{
		echo "record is update";
	}
	else
	{
		printf("could not Update into: %s\n",mysqli_error($mysqli));
	}
	mysqli_close($mysqli);
}
?>
<a href="display.php">Back</a>