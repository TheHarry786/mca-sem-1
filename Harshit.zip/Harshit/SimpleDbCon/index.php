<form method="post" action="insert.php">

	<br/>
	First name :<input type = "text" name="fname">
	
	<br/>
	Middle name :<input type = "text" name="mname">
	
	<br/>
	Last name :
	<input type = "text" name="lname">
	
	<br/>
	<input type="submit" name= "submit" value="Insert">
	<a href="update.php">Update</a>
</form>