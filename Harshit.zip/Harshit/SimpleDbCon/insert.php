<?php
$mysqli = mysqli_connect("localhost","root","","jvims");

if(mysqli_connect_errno())
{
	printf("connect failed: %s\n",mysqli_connect_error());
	exit();
}
else
{
    $fm = $_POST["fname"];
	$mn = $_POST["mname"];	
	$ln = $_POST["lname"];
	

	$sql = "insert into testtable (fname,mname,lname) values ('$fm','$mn','$ln')";
	//echo  $sql;
	$res=mysqli_query($mysqli, $sql);
	
	if($res === TRUE)
	{
		echo "record is insert";
	}
	else
	{
		printf("could not insert into: %s\n",mysqli_error($mysqli));
	}
	mysqli_close($mysqli);
}
?>	
	<a href="index.php">Back</a>
	<a href="update.php">Update</a>