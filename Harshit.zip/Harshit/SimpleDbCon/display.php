<?php
$mysqli = mysqli_connect("localhost","root","","jvims");

if(mysqli_connect_errno())
{
	printf("connect failed: %s\n",mysqli_connect_error());
	exit();
}
else
{
		
		
	$sql= "Select id,fname,mname,lname from testtable order by id";
	$res = mysqli_query($mysqli,$sql);
	if($res->num_rows>0)
	{	
		echo "<h1 align='center'>Data Display</h1>";
		echo "</br>";
		//echo "show records";
		echo "<table border='5' align='center' bordercolor='red'>";
		
		
		while($row = mysqli_fetch_array($res, MYSQLI_ASSOC))
		{	
			$id = $row['id'];
			$fm = $row['fname'];
			$mn = $row['mname'];	
			$ln = $row['lname'];
			
			
		
			
			
			echo "<tr><td>$id</td><td>$fm</td>
			<td>$mn</td><td>$ln</td><td><a href='edit.php?id=$id' 
			onClick=\"return confirm('are you sure to Update this data??');\">
			Edit</a></td><td><a href='delete.php?id=$id' 
			onClick=\"return confirm('are you sure to delelte this data??');\">
			Delete</a></td></tr>";
			
			
		}
		
		//var_dump($res);
		
		
		echo "</table>";
		
	}
	else
	{	
		echo "no records available";
	}
	
	/*echo "<input type='text' name='txt' id='txt'>
			<input type='submit' name= 'Search' value='Search' id='search'>";
		
		$sq= "Select * from testtable fname LIKE '$fm%'";
		$wq= mysqli_query($mysqli,$sq);
		
		if($res->num_rows>0)
		{
			
		}*/
}

?>
<a href="insert.php">Insert</a>
