<?php
$mysqli = mysqli_connect("localhost","root","","jvims");

if(mysqli_connect_errno())
{
	printf("connect failed: %s\n",mysqli_connect_error());
	exit();
}
else
{
	
	//echo  $sql;
	
	
	$id = $_GET['id'];
	
	$sql = "delete from testtable where id= $id";
	echo $sql;
	$res=mysqli_query($mysqli, $sql);
	if($res === TRUE)
	{
		echo "record is Delete";
	}
	else
	{
		printf("could not insert into: %s\n",mysqli_error($mysqli));
	}
	mysqli_close($mysqli);
}
?>
<a href="display.php">Back</a>