
<?php
$mysqli = mysqli_connect("localhost","root","","jvims");

if(mysqli_connect_errno())
{
	printf("connect failed: %s\n",mysqli_connect_error());
	exit();
}
else
{
	$id = $_GET['id'];
	$sql ="select id,fname,mname,lname from testtable where id=$id";
	$res = mysqli_query($mysqli,$sql);
	
	if($res->num_rows)
	{
		$row = mysqli_fetch_array($res, MYSQLI_ASSOC);
		
		$id = $row['id'];
		$fm = $row['fname'];
		$mn = $row['mname'];	
		$ln = $row['lname'];
		
		?>
		<form method="post" action="update.php">
			<br/>
			<input type = "hidden" name="id" value="<?=$id?>">
			First name :<input type = "text" name="fname"  value="<?=$fm?>">
			
			<br/>
			Middle name :<input type = "text" name="mname" id="fname" value="<?=$mn?>">
			
			<br/>
			Last name :
			<input type = "text" name="lname" id="mname" value="<?=$ln?>">
			
			<br/>
			<input type="submit" name= "submit" value="Update">		
		</form>
		<?php
	}
	else
	{
		printf("could not insert into: %s\n",mysqli_error($mysqli));
	}
	mysqli_close($mysqli);
}

?>	
	<a href="display.php">Back</a>