<form action="" method="POST">
	<input type="textbox" name="tx"/>
	<input type="submit" name="Search" value="Search"/>
</form>
<?php
	if(isset($_POST['Search']))
	{
		//include("conn.php");
				function data()
				{
					
					.
				include("conn.php");
				$sql1 = "select trainno, code, name, type ,starting_city, destination_city,falg from train ";
				$sql1 .= " order by trainno";

				$res1 = mysqli_query($mysqli, $sql1);
					if($res1->num_rows>0)
					{
						
						//echo "Show records";
						echo "<table border='1' cellpadding='5px' align='center'>";
						while($row = mysqli_fetch_array($res1, MYSQLI_ASSOC))
						{	
							$id=$row['trainno'];
							$td=$row['type'];
							$sd=$row['starting_city'];
							$dd=$row['destination_city'];
							$fl=$row['falg'];

							$t=$_POST['tx'];
							if($t==$sd)
							{
								echo "<tr><td>$id</td><td>$sd</td><td>$td</td>";
								echo "<td>$dd</td><td>$fl</td>";
								
								echo "</tr>";
						
							}	
							else if($t==$td)
							{
								echo "<tr><td>$id</td><td>$sd</td><td>$td</td>";
								echo "<td>$dd</td><td>$fl</td>";
								
								echo "</tr>";
							}
							else if($t==$fl)
							{
								echo "<tr><td>$id</td><td>$sd</td><td>$td</td>";
								echo "<td>$dd</td><td>$fl</td>";
								
								echo "</tr>";
							}
						}
					}
				}
	
							
			
		
		data();
		
	}
		
	
?>