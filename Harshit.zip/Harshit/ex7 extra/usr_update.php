
<?php
	
	if(isset($_GET['uid']))
	{
		$id=$_GET['uid'];
			
				
				//$cookie_value=$w;
				
				?>
				<form method="post" action="">
					name :<input type="text" name="name" value="<?php echo $id ?>"/>
					values : <input type="text" name="value" />
					Submit <input type="submit" name="update"/>
				</form>
				
				<?php
				
				if(isset($_POST['update']))
				{
					$cn=$_POST['name'];
					$cv=$_POST['value'];
					
					setcookie($cn,$cv, time() + (86400)*30,"/"); //86400 = 1 day
					
					if(!isset($_COOKIE[$cn]))
					{
					echo "cookie name '". $cn . "' is not updated!";	
						
					}
					else
					{
						echo "cookie :". $cn;
						echo "cookie value is :". $cv;
						header("location:usr_form cookie.php");
					}
				}
		
	}
	
?>