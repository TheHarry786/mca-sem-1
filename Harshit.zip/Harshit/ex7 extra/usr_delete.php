<?php
	$id=$_GET['id'];
	
	setcookie($id, null, time() -10, "/");
	 unset($_COOKIE[$id]);
	echo "Cookie $id is deleted";
	echo "<a href='form cookie.php'>back</a>";
	header("location:usr_form cookie.php");
?>