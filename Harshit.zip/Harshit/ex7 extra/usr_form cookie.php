<form method="post" action="">
	name :<input type="text" name="name"/>
	values : <input type="text" name="value"/>
	Submit <input type="submit" name="submit"/>
</form>

<?php
	if(isset($_POST['submit']))
	{
		$cookie_name=$_POST['name'];
		$cookie_value=$_POST['value'];
	
		setcookie($cookie_name, $cookie_value, time() + (86400)*30,"/"); //86400 = 1 day
		
		if(!isset($_COOKIE[$cookie_name]))
		{
			echo "cookie name '". $cookie_name . "' is not set!";
		}
		
		else
		{
			echo "cookie :". $cookie_name;
			echo "cookie value is :". $cookie_value;
		}
	}
		foreach ($_COOKIE as $key=>$val)
		  {
			echo "<table border='5px'><td>".$key."</td>".
			' '."<td>".$val."</td><td><a href='usr_update.php?uid=$key' name='update'>Edit</a></td>
			<td><a href='usr_delete.php?id=$key' name='delete'>Delete</a></td></table>"."<br>\n";
		  
		  }
		
	
	
?>