<?php

	function f1($a,$b)
	{
		echo "hi".$a."-".$b;
	}
	f1("harshit","pandya");
?>