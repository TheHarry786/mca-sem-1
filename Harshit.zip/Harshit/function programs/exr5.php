<?php
	$a="harshit";
	$b="Pandya";
	$c="pandya harshit";
	
	echo "<br>".ucfirst($a);
	echo "<br>".lcfirst($b);
	echo "<br>".ucwords($c);
?>