<?php
function f1()
{
	echo "hello harshit";
}
f1();
function f2($ans='c')
{
	echo "<br> String :";
	echo $ans;
	echo "<br> Strlen :";
	echo strlen($ans);
}
echo f2('harshit pandya a');
echo f2('hey there','harshit');
//$ans="harshit pandya";
//$ans="hey there";
f2();
function sum_my_numbers(...$numbers)
{
	$sum=0;
	$count=0;
	foreach($numbers as $n)
	{
		$sum += $n;
		$count++;
	}
	echo "<br/>Total argument : ".$count;
	echo "<br/>";
	return $sum;
}
echo "<br/>";
echo sum_my_numbers(10,20,30,40);
echo "<br/>";
echo sum_my_numbers(10,20);
echo "<br/>";
?>