<?php
function f1(...$a)
{
	var_dump($a);
	echo "<br> sum is : ".array_sum($a);
}
f1(1,23,67);
?>
