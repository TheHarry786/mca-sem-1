<?php
function f1(&f1)
{
	$a= "hi".$a;
	return $a;
}

$a="harshit";
$ans=f1($a);
echo $a;
?>