<?php
$a="harshit ";
function f1()
{	echo $GLOBALS['a'];
	$a="hey";
	
	
	$a="helllo ".$a;
	return $a;
}
$ans=f1();
echo $ans;
?>