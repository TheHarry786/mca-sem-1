<?php
$a="harshit";
function f1()
{	
	$a="hey";
	global $a;
	
	$a="helllo ".$a;
	return $a;
}
$ans=f1();
echo $ans;
?>