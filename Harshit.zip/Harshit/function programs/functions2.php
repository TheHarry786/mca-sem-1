<?php
function f1(&$a)
{
	$a= "hi".$a;
	return $a;
}

$a="harshit";
$ans=f1($a);
echo $a;
?>