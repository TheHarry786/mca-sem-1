<?php
	function display()
	{	
		$conn= new mysqli("localhost","root","","jvims");
		$sql = "select * from user";

		$res = $conn->query($sql);

		if($res->num_rows>0)
		{
			//echo "Show records";
			echo "<table border='1' cellpadding='5px' align='center'>";
			while($row = mysqli_fetch_array($res, MYSQLI_ASSOC))
			{
				$id=$row['id'];
				$nm=$row['user_name'];
				$ps=$row['password'];
				$mb=$row['mobile'];
				echo "<tr><td>$id</td><td>$nm</td>";
				echo "<td>$ps</td><td>$mb</td>";
				echo "</tr>";	

			}
			echo "</table>";
	
		}

	}

	display(); 
?>
<?php
	session_start();
?>
<form align="center" action="forget.php" method="post">
	User Name : <input type="text" name="name" ><br/><br/>
	New Password Enter : <input type="password" name="ps" >
	<input type="submit" name="submit" value="Update Password">
	<a href="login.php">Back</a>
</form>
<?php
	if(isset($_POST['submit']))
	{

			$un=$_POST['name'];
			$ps = $_POST['ps'];

			$mysqli = new mysqli("localhost","root","","jvims");

			
			$sql= "Select * from user where user_name='$un'";
				
			$res = $mysqli->query($sql1);
			if($res->num_rows > 0 )
			{

				$row=$res->fetch_assoc();
				$id=$row['id'];
				$_SESSION['name']=$row['user_name'];
				$_SESSION['ps']=$row['password'];
				//echo "Your Password is : ".$_SESSION['ps'];
				echo "Password Is Updated";
				echo $_SESSION['ps'];
			}
			else
			{
				echo"forget password not work try agian!!!";
			}
			$mysqli->close();
	}
?>/*if(isset($_POST['submit']))
	{

			$un=$_POST['name'];

			$mysqli = new mysqli("localhost","root","","jvims");

			
			$sql= "Select * from user where user_name='$un'";
			
			$res = $mysqli->query($sql);
			if($res->num_rows > 0 )
			{
				$row=$res->fetch_assoc();
				$_SESSION['ps']=$row['password'];
				echo "Your Password is : ".$_SESSION['ps'];
			}
			else
			{
				echo"forget password not work try agian!!!";
			}
			$mysqli->close();
	}*/

	
	<?php
session_start();
?>
	<?php	
		function display()
		{
			
			$mysqli = mysqli_connect("localhost", "root", "", "jvims");

			if (mysqli_connect_errno())
			{
				printf("Connect failed: %s\n", mysqli_connect_error());
				exit();
			}
			$sql1 = "select * from user ";

			$res1 = mysqli_query($mysqli, $sql1);

			if($res1->num_rows>0)
			{
				//echo "Show records";
				echo "<table border='1' cellpadding='5px' align='center'>";
				while($row = mysqli_fetch_array($res1, MYSQLI_ASSOC))
				{
					$id=$row['id'];
					$fname=$row['user_name'];
					$mname=$row['password'];
					echo "<tr><td>$id</td><td>$fname</td>";			
					echo "<td><a href='forget.php?id=$id'>edit</a></td>";
					echo "</tr>";	

				}
				echo "</table>";
		
			}
		}
	display();
	function edit()
	{

		$mysqli = mysqli_connect("localhost", "root", "", "jvims");

		if (mysqli_connect_errno())
		{
			printf("Connect failed: %s\n", mysqli_connect_error());
			exit();
		}
		if(isset($_GET['id']))
		
		{
			$id=$_GET['id'];
			
			$sql = "select * from user";
			$res = mysqli_query($mysqli, $sql);
			if($res->num_rows)
			{	
				$row = mysqli_fetch_array($res, MYSQLI_ASSOC);
				$id  = $row['id'];
				$nm = $row['user_name'];
				$ps = $row['password'];
				?>
					<form method="POST">
					<input type="text" name="id" value="<?=$id?>">
					<br/>User Name : <input type="text" name="name">
					<br/>New password: <input type="password" name="ps">
					<input type="submit" name="submit" value="update">	
					<a href="login.php">Back</a>
								
					<br/>
					</form>
				<?php
				
			}

				$mysqli = mysqli_connect("localhost", "root", "", "jvims");

				if (mysqli_connect_errno())
				{
					printf("Connect failed: %s\n", mysqli_connect_error());
					exit();
				}
			if(isset($_POST['submit']))
			{

				$id=$_POST['id'];
				$un=$_POST['name'];
				$ps=$_POST['ps'];
				
				//$sql= "Select * from user where user_name='$un'";
				$sql = "update user set password ='$ps' WHERE id='$id'";
				$res = mysqli_query($mysqli, $sql);
				if($res === TRUE)
				{
					echo "A record has been updated.";
					
				}
				else
				{
					echo"forget password not work try agian!!!";
				}
			}
			
		}
	}
	edit();
?>-->