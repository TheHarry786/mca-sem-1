<h2 align="center">Forget Password :</h2>
<form align="center" action="forget.php" method="post">
	User Name : <input type="text" name="name" required="" ><br/><br/>
	enter new password : <input type="text" name="ps" required=""><br/><br/>
	confirm password : <input type="text" name="cps" required=""><br/><br/>
	<input type="submit" name="submit" value="Update Password">
	<a href="login.php">Back</a>
</form>
<?php
if(isset($_POST["submit"]))
{
	include("conn.php");

	$sql = "select user_name,password from user";
	$res1 = mysqli_query($mysqli, $sql);	

		$nm=$_POST['name'];

		$ps=$_POST['ps'];
		$cps=$_POST['cps'];
	if($ps != $cps)
	{
			echo "error!! user not found otherwise password not match";
	}
	else
	{
		
		include("conn.php");

		$sql = "update user set password = '$ps' where user_name='$nm'";
		$res = mysqli_query($mysqli, $sql);
			 
			if ($res === TRUE) {
				echo "Your Password has been updated.";
			} else {
				echo "plese try agian!! something wrong..";
				header("location:login.php");
			}
			mysqli_close($mysqli);
	}
	
}
	
	
?>