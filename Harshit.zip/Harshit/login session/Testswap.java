class Testswap
{
	int a;
	Test(int i)
	{
		a=i;
	}
	void display()
	{
		System.out.println("obj1"+a);
		System.out.println("obj2"+a);
		
	}
	public static void main(String args[])
	{
		int obj1=20;obj2=10;
		
		void swap()
		{
			int t;
			t=obj1;
			obj1=obj2;
			obj2=t;
		}
		Test t = new Test(obj1);
		t.display();
		Test t1 = new Test(obj2);
		t1.display();
	}
}