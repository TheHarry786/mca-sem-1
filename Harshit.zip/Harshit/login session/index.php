
<?php
	
	
	function insert()
	{
		?>
		<form align="center" method="POST" action="">
			<h1 style="font-size:70px;color: Red;"><b>Registration Form<b/></h1>
			<br/><br/>
			<h2 style="font-size :30px;"><b>User Name :</b> <input type="text" name="name" required><br/><br/></h2>
			<h2 style="font-size:30px;"><b>Pasword   :</b> <input type="text" name="ps" required style="margin-left:25px;"><br/><br/></h2>
			<h2 style="font-size:30px;"><b>Mobile NO :</b> <input type="text" name="mob" required><br/><br/></h2>
			<input type="submit" name="submit" value="Registraion">
			<a href="login.php">Login</a>
		</form>
		<?php

		$conn= new mysqli("localhost", "root", "", "login");
		if(isset($_POST['submit']))
		{
			$nm = $_POST['name'];
			$ps = $_POST['ps'];
			$mn = $_POST['mob'];
		
			$sql="insert into user(user_name,password,mobile) VALUES ('$nm','$ps','$mn')";
			$res = $conn->query($sql);

			if ($res === TRUE) {
				echo "A record has been inserted.";
			} else {
				echo "not inserted..";
			}
			mysqli_close($conn);
			header("location:login.php");
		}
	}
	insert();
	

?>


