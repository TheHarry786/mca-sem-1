<?php
	session_start();
?>
<form method="post" align="center">
	<h1 style="font-size: 50px; color: blue;">User Login</h1>
	<h2><b>User Name :</b> <input type="text" name="name"><br/><br/></h2>
	<h2 style="margin-left:150px;"><b>Password :</b> <input type="password" name="ps"> 
		<b><a href="forget.php" style="margin-right:-50px;">Forget Password</a></b><br/><br/>
		<b><a href="forget2.php" style="margin-right:-50px;">Forget Password show</a></b><br/><br/></h2>
<input type="submit" name="submit" value="Login">
<a href ="index.php">Registraion</a>
<?php
		if(isset($_POST['submit']))
		{
			
			$un=$_POST['name'];
			$ps=$_POST['ps'];
			
			include('conn.php');

			
			$sql= "Select * from user where user_name='$un' and password='$ps'";
			
			$res = $mysqli->query($sql);
			if($res->num_rows > 0 )
			{
				$row=$res->fetch_assoc();
				$_SESSION['id']=$row['id'];
				$_SESSION['name']=$un;
				header("location:welcome.php");
			}
			else
			{
				echo"login failed try agian!!!";
			}
			header("Location:welcome.php");
			$mysqli->close();
		}
?>