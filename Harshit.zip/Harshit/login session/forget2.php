<form align="center" method="POST" action="">
			<h1 style="font-size:70px;color: Red;"><b>Forget password show<b/></h1>
			<br/><br/>
			<h2 style="font-size :30px;"><b>User Name :</b> <input type="text" name="name" required><br/><br/></h2>
			<input type="submit" name="submit" value="show password">
			<a href="login.php">back</a><br/>
			<a href="forget.php">Update Password</a>
</form>
<?php

	if(isset($_POST['submit']))
	{

			$un=$_POST['name'];

			$mysqli = new mysqli("localhost","root","","login");

			
			$sql= "Select * from user where user_name='$un'";
			
			$res = $mysqli->query($sql);
			if($res->num_rows > 0 )
			{
				$row=$res->fetch_assoc();
				$_SESSION['ps']=$row['password'];
				echo "Your Password is : ".$_SESSION['ps'];
			}
			else
			{
				echo"forget password not work try agian!!!";
			}
			$mysqli->close();
	}
?>