<?php
session_start();
	if(isset($_SESSION['uid']))
	{
		echo "welcome".$_SESSION['unm'];
		
	}
	else
	{
		echo "error";
		header("location:index.php");
	}
?>