
<form method="GET" action="save.php">
	
	First Name :<input type="text" name="Fname"><br/>
	
	Middle name:<input type="text" name="Mname"><br/>
	Last name:  <input type="text" name="Lname"><br/><br/>
	
	gender:
	Male :<input type="radio" name="m" value="male" checked>
	Feamle:<input type="radio" name="m" value="female"><br/>
	
	Date : <input type="Date" name="date"><br/><br/>
	
	Email : <input type="Email" name="ema"><br/>
	mobileno : <input type="number" name="mns"><br/><br/>
	
	language known:<br/>
	Gujarati :<input type="checkbox" name="ck1" value="Gujarati" checked> <br/>
	Hindi :<input type="checkbox" name="ck2" value="Hindi"> <br/> 
	English :<input type="checkbox" name="ck3" value="English"> <br/><br/>
	
	city: <select name="city" >
	
			<option value="sr">----Select City----</option>
			<option value="jm">Jamnagar</option>
			<option value="rk">Rajkot</option>
			<option value="am">Amreli</option>		
		</select><br/><br/>
	
	address:
	<textarea name="adr" rows="4" cols="30"></textarea><br/><br/>
	
	img :
	<input type="file" name="iimg"><br/><br/>
	
	<input type="submit" name="save">
	
</form>

