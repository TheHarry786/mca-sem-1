<?php
$fm = $_GET['Fname'];
echo $fm. ' ';

$mm = $_GET['Mname'];
echo $mm. ' ';

$lm= $_GET['Lname'];
echo '<br/>'.$lm;

$m = $_GET['m'];
echo '<br/>'.$m;

$d= $_GET['date'];
echo '<br/>'.$d;

$e= $_GET['ema'];
echo '<br/>'.$e;

$mno= $_GET['mns'];
echo '<br/>'.$mno;
if(isset($_GET['ck1']))
{
		$c1= $_GET['ck1'];
		echo '<br/>'.$c1;

}
if(isset($_GET['ck2']))
{
		$c2= $_GET['ck2'];
		echo '<br/>'.$c2;

}


if(isset($_GET['ck3']))
{
		$c3= $_GET['ck3'];
		echo '<br/>'.$c3;

}

$s = $_GET['city'];
echo '<br/>'.$s;

$ad = $_GET['adr'];
echo '<br/>'.$ad;

$i = $_GET['iimg'];
echo '<br/>'.$i;

?>