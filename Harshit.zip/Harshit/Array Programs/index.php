<?php
	$n = array(4, 6, 2, 22, 11);
	for($i=0;$i<count($n);$i++)
	{
		echo $n[$i]."<br>";
	}
	
	
?>
