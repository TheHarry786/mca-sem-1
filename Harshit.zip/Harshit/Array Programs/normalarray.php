<?php
$a=array("harshit","pandya");

echo $a[0].'<br>'.$a[1].'<br>';
var_dump($a);
echo '<br>'."counting is ".count($a).'<br>';
echo '<br>';
echo '<br>';
rsort($a);
var_dump($a);

echo '<br>';
echo '<br>';
$a1 =array("name"=>"harry","age"=>21,"city"=>"jamnagar");
echo '<br>'.$a1['name'].'<br>'.$a1['age'].'<br>'.$a1['city'].'<br>';
var_dump($a1).'<br>';
echo '<br>'."counting is ".count($a1).'<br>';
sort($a1);

echo '<br>';
arsort($a1);
var_dump($a1);
?>