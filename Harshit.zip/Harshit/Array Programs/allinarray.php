<?php
$a=array("fname"=>"harshit","mname"=>"a","lname"=>"Pandya");
$cars=array("Volvo","BMW","Toyota");
print_r($cars);
for($i=0;$i<count($cars);$i++)
{
	echo "<br/>[$i] : ".$cars[$i];
}
echo "<br>";
echo "----------";
echo "<br>";

foreach($cars as $i)
{
	echo "<br>";
	echo $i;	
}
echo "<br>";
echo "----------";
echo "<br>";

foreach($a as $k => $v)
{
	echo "Key=". $k .", Value=" . $v;
	echo "<br>";
}
echo "<br>";
echo "----Sorting-----";
echo "<br>";

print_r($cars);
sort($cars);
echo "<br>";

print_r($cars);
rsort($cars);
echo "<br>";

print_r($cars);
echo "<br>";
echo "<br>";
echo "---associative sorting value---";
echo "<br>";

print_r($a);
asort($a);
echo "<br>";


print_r($a);
arsort($a);
echo "<br>";

print_r($a);
echo "<br>";echo "<br>";
echo "---associative sorting Key---";

$a=array("fname"=>"harshit","mname"=>"a","lname"=>"Pandya");

echo "<br>";
print_r($a);

ksort($a);
echo "<br>";
print_r($a);

krsort($a);
echo "<br>";
print_r($a);
?>