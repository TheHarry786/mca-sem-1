<?php
$a=array("a,b,c");
$b=array("aa,bb,cc");
$c=array_merge($a,$b);

print_r($a);
echo "<br>";

print_r($b);
echo "<br>";

print_r($c);
echo "<br>";
$n=array(1,2,3,4,5,6,7,8,99);
echo array_sum($n);

$t=0;
for($i=0;$i<count($n);$i++)
{
	$t=$t+$n[$i];
}
echo "<br> t :".$t;
?>