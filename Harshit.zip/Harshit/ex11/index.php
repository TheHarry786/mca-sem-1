<!--epoch time time() midnight 12:00 1 jan 1970-->

<form enctype="multipart/form-data" method="POST">
Select Image : <input type="file" name="image" id="image" accept="image/JPEG"/>
<input type="submit" value="Upload" name="up">
</form>
<?php
$conn= new mysqli("localhost","root","","jvims");
if(isset($_POST['up']))
{
	if(isset($_FILES['image']))
	{
		$name = "".time();
		$fp=addslashes(file_get_contents($_FILES['image']['tmp_name']));
		$sql="INSERT INTO image VALUES('null','{$name}','{$fp}');";
		$conn->query($sql);
	}	
}
?>
<?php
	$sql="select * from image";
	$result=$conn->query($sql);
	echo "<table border='2'>";
	echo"<tr><th>ID</th><th>Image Name</th><th>Image</th></tr>";
	for($i=0;$i<$result->num_rows;$i++)
	{
		echo "<tr>";
			$row= $result->fetch_object();
			echo "<td>";
				echo $row->id;
			echo "</td>";
			echo "<td>";
				echo $row->image_name;
			echo "</td>";
			echo "<td>";
				$image=$row->image;
				$msg='<a href="#"><img height="100px" src="data:image/jpeg;base64,'.base64_encode($image).'"/></a>';
				echo $msg;
			echo "</td>";
		echo "</tr>";
	}
	echo "</table>";
?>