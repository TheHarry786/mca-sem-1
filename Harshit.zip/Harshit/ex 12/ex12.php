<h1 align="center">
<?php
	echo $_REQUEST['myname']??"";
	if(isset($_REQUEST['page']))
	{
		echo "you are on page -".$_REQUEST['page'];
	}
	else
	{
		echo "Welcome to my website";
	}
	echo "<br/><br/><br/>";
	$n=10;
	for($i=1;$i<=$n;$i++)
	{	
		echo "<a href='ex12.php?page=$i'> $i</a> |";
	}
?></h1>