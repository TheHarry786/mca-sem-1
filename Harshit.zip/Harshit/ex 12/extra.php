<h1 align="center">
<?php
	$mysqli = mysqli_connect("localhost", "root", "", "jvims");

	if (mysqli_connect_errno()) {
		printf("Connect failed: %s\n", mysqli_connect_error());
		exit();
	}
	
	
	$sql = "select  * from testtable LIMIT 0,3";
		
	$res1 = mysqli_query($mysqli, $sql);

	echo $_REQUEST['myname']??"";
	if(isset($_REQUEST['page']))
	{
		echo "you are on page -".$_REQUEST['page'];
		
		if($res1->num_rows>0)
		{	
			echo "<table border='1' cellpadding='5px' align='center'>";
				while($row = mysqli_fetch_array($res1, MYSQLI_ASSOC))
				{
					$id=$row['fname'];
					$name=$row['mname'];
					$item=$row['lname'];
					$mno=$row['id'];
					echo "<tr><td>$id</td><td>$name</td>";
					echo "<td>$item</td><td>$mno</td>";
					echo "<td><a href='index.php?id=$id'>Edit</a></td>";
					echo "<td><a href='index.php?did=$id'>delete</a></td>";
					echo "</tr>";	

				}
				echo "</table>";
		}
	}
	else
	{
		
		$sql1 = "select  * from testtable";
		$res1 = mysqli_query($mysqli, $sql1);
		echo "Welcome to my website";
		if($res1->num_rows>0)
	{	
		echo "<table border='1' cellpadding='5px' align='center'>";
			while($row = mysqli_fetch_array($res1, MYSQLI_ASSOC))
			{
				$id=$row['fname'];
				$name=$row['mname'];
				$item=$row['lname'];
				$mno=$row['id'];
				echo "<tr><td>$id</td><td>$name</td>";
				echo "<td>$item</td><td>$mno</td>";
				echo "<td><a href='index.php?id=$id'>Edit</a></td>";
				echo "<td><a href='index.php?did=$id'>delete</a></td>";
				echo "</tr>";	

			}
			echo "</table>";
	}
	}
	echo "<br/><br/><br/>";
	$n=3;
	for($i=1;$i<=$n;$i++)
	{	
		echo "<a href='extra.php?page=$i'> $i</a> |";
	}
?></h1>