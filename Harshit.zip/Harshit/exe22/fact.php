<?php
 
        $mysqli = mysqli_connect("localhost", "root", "", "jvims");
        if (mysqli_connect_errno()) {
            printf("connection failed: %s\n", mysqli_connect_error());
            exit();
        }
        $id = $_GET['did'];
        $sql = "select * from faculty where did=$id";
        $res = mysqli_query($mysqli, $sql);

        if ($res->num_rows > 0) 
        {
            echo "<table border='2px' align='center'>";
            echo "<tr><th>No</th><th>Name</th></tr>";
            while ($row = mysqli_fetch_array($res, MYSQLI_ASSOC)) {
                $dno = $row['fid'];
                $dn = $row['f_name'];
                echo "<tr><td>$dno</td><td>$dn</td></tr>";
            }
            echo "</table><br><br>";
        }

?>