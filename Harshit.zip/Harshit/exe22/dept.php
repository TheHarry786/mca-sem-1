<?php
 
        $mysqli = mysqli_connect("localhost", "root", "", "jvims");
        if (mysqli_connect_errno()) {
            printf("connection failed: %s\n", mysqli_connect_error());
            exit();
        }
        $id = $_GET['id'];
        $sql = "select * from dept where iid=$id";
        $res = mysqli_query($mysqli, $sql);

        if ($res->num_rows > 0) 
        {
            echo "<table border='2px' align='center'>";
            echo "<tr><th>No</th><th>Name</th></tr>";
            while ($row = mysqli_fetch_array($res, MYSQLI_ASSOC)) {
                $dno = $row['did'];
                $dn = $row['dname'];
                echo "<tr><td>$dno</td><td><a href='fact.php?did=$dno'>$dn</a></td></tr>";
            }
            echo "</table><br><br>";
        }

?>