<?php
        $mysqli = mysqli_connect("localhost", "root", "", "jvims");
        if (mysqli_connect_errno()) {
            printf("connection failed: %s\n", mysqli_connect_error());
            exit();
        }

        $sql = "select * from institute";
        $res = mysqli_query($mysqli, $sql);

        if ($res->num_rows > 0) {
            echo "<h1 align='center'>Institue Display</h1>";
            echo "<table border='2px' align='center'>";
            echo "<tr><th>No</th><th>Name</th></tr>";
            while ($row = mysqli_fetch_array($res, MYSQLI_ASSOC)) {
                $iid = $row['i_id'];
                $iname = $row['i_name'];
                echo "<tr><td>$iid</td><td><a href='index.php?id=$iid'>$iname</a></td></tr>";
            }
            echo "</table><br><br>";
        }

function f2()
{
    if(isset($_GET['id']))
    {
        $mysqli = mysqli_connect("localhost", "root", "", "jvims");
        if (mysqli_connect_errno()) {
            printf("connection failed: %s\n", mysqli_connect_error());
            exit();
        }
        $id = $_GET['id'];
        $sql = "select * from dept where iid=$id";
        $res = mysqli_query($mysqli, $sql);

        if ($res->num_rows > 0) 
        {
            echo "<h1 align='center'>Depart Display</h1>";
            echo "<table border='2px' align='center'>";
            echo "<tr><th>No</th><th>Name</th></tr>";
            while ($row = mysqli_fetch_array($res, MYSQLI_ASSOC)) {
                $dno = $row['did'];
                $dn = $row['dname'];
                echo "<tr><td>$dno</td><td><a href='index.php?did=$dno'>$dn</a></td></tr>";
            }
            echo "</table><br><br>";
        }
    }
}

function f3()
{
    if(isset($_GET['did']))
    {
        $mysqli = mysqli_connect("localhost", "root", "", "jvims");
        if (mysqli_connect_errno()) {
            printf("connection failed: %s\n", mysqli_connect_error());
            exit();
        }
        $id = $_GET['did'];
        $sql = "select * from faculty where did=$id";
        $res = mysqli_query($mysqli, $sql);

        if ($res->num_rows > 0) 
        {
            echo "<h1 align='center'>Fact Display</h1>";
            echo "<table border='2px' align='center'>";
            echo "<tr><th>No</th><th>Name</th></tr>";
            while ($row = mysqli_fetch_array($res, MYSQLI_ASSOC)) {
                $dno = $row['fid'];
                $dn = $row['f_name'];
                echo "<tr><td>$dno</td><td>$dn</td></tr>";
            }
            echo "</table><br><br>";
        }

    }
}
f2();
f3();


?>