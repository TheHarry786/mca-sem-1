<!--20. Write a program to calculate total weekly pay. If the user enters the number of hours
worked and selects the hourly rate of pay from a list box. If overtime has been done,
the number of hours is also entered. Over time hours are paid at double rate. A check
box displays overtime. Calculate total amount to be paid.-->

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body bgcolor="yellow">
	<h1 align="center">Total Weekly Pay</h1>
	<form method="post" align="center">
	Enters Hours : <input type="number" name="hours">
	<br/>
	<br/>
	Hourly rate of pay :
	<select name="pay">
		<option value="Select">---Select---</option>
		<option value="3000">3000</option>
		<option value="6000">6000</option>
		<option value="10000">10000</option>
		<option value="15000">15000</option>
	</select>

	<br/>
	<br/>

	Any over time? <input type="checkbox" name="chk1" onchange="document.getElementById('txt2').disabled = !this.checked;"><br><br>
    over time hours: <input type="number" name="txt2" id="txt2" disabled><br><br>
	<br/>
	<br/>

	<input type="submit" name="cal">
	<?php
		if(isset($_POST['cal']))
		{
			$n = $_POST['hours'];
			$p = $_POST['pay'];
			
			if($p!="" && $n!="")
			{
				if(isset($_POST['chk1']))
				{
					$h = $_POST['txt2'];
					if($h!="")
	            	{
	            	   	$cal = (($h*($p*2))+($n*$p));
	              	  echo "Payable Amount is - ".$cal;
	            	}
	            	else
	            	    echo "over time hours?"; 
				}
				else
				{
					$cal = $n*$p;
					echo "<br/><br/><h2><b>Total Amount :</b></h2>".$cal;
				}
			}
			else
			{
				echo "no data";
			}

		}
	?>
</body>
</html>